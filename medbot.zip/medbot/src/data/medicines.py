import pandas as pd
import json
from typing import List, Dict, Optional
import re

class MedicineDataProcessor:
    def __init__(self, excel_path: str):
        """Initialize with medicine Excel data"""
        self.df = pd.read_excel(excel_path)
        self.medicines = self._process_data()
    
    def _process_data(self) -> List[Dict]:
        """Process and clean medicine data"""
        medicines = []
        for _, row in self.df.iterrows():
            medicine = {
                'name': str(row['Name']).strip(),
                'company': str(row['Company']).strip(),
                'price_before': self._parse_price(row['Price_before']),
                'discount': str(row['Discount']).strip() if pd.notna(row['Discount']) else '',
                'price_after': float(row['Price_After']) if pd.notna(row['Price_After']) else 0.0,
                'pack_size': str(row['Pack_Size']).strip() if pd.notna(row['Pack_Size']) else '',
                'availability': str(row['Availability']).strip()
            }
            medicines.append(medicine)
        return medicines
    
    def _parse_price(self, price_str) -> float:
        """Parse price from string format like 'Rs 202'"""
        if pd.isna(price_str):
            return 0.0
        
        price_str = str(price_str)
        # Remove 'Rs' and commas, extract numbers
        numbers = re.findall(r'[\d,]+', price_str.replace('Rs', '').replace(',', ''))
        if numbers:
            try:
                return float(numbers[0])
            except ValueError:
                return 0.0
        return 0.0
    
    def search_by_name(self, medicine_name: str) -> List[Dict]:
        """Search medicines by name (partial match)"""
        name_lower = medicine_name.lower()
        return [m for m in self.medicines if name_lower in m['name'].lower()]
    
    def search_by_company(self, company_name: str) -> List[Dict]:
        """Search medicines by company"""
        company_lower = company_name.lower()
        return [m for m in self.medicines if company_lower in m['company'].lower()]
    
    def get_available_medicines(self) -> List[Dict]:
        """Get only available medicines"""
        return [m for m in self.medicines if m['availability'].lower() == 'available']
    
    def get_medicine_alternatives(self, medicine_name: str) -> List[Dict]:
        """Get alternative medicines with similar names"""
        # Find medicines with similar names (first word match)
        first_word = medicine_name.split()[0].lower()
        alternatives = []
        
        for medicine in self.medicines:
            med_first_word = medicine['name'].split()[0].lower()
            if first_word in med_first_word or med_first_word in first_word:
                if medicine['availability'].lower() == 'available':
                    alternatives.append(medicine)
        
        # Sort by price (ascending)
        alternatives.sort(key=lambda x: x['price_after'])
        return alternatives[:10]  # Return top 10 alternatives
    
    def get_medicines_by_price_range(self, min_price: float, max_price: float) -> List[Dict]:
        """Get medicines within a price range"""
        return [m for m in self.medicines 
                if min_price <= m['price_after'] <= max_price 
                and m['availability'].lower() == 'available']
    
    def get_cheapest_medicines(self, medicine_name: str, limit: int = 5) -> List[Dict]:
        """Get cheapest available versions of a medicine"""
        matches = self.search_by_name(medicine_name)
        available = [m for m in matches if m['availability'].lower() == 'available']
        available.sort(key=lambda x: x['price_after'])
        return available[:limit]
    
    def get_medicine_info(self, medicine_name: str) -> Dict:
        """Get detailed information about a specific medicine"""
        matches = self.search_by_name(medicine_name)
        if not matches:
            return None
        
        # Get all variants
        available = [m for m in matches if m['availability'].lower() == 'available']
        sold_out = [m for m in matches if m['availability'].lower() != 'available']
        
        if available:
            cheapest = min(available, key=lambda x: x['price_after'])
            most_expensive = max(available, key=lambda x: x['price_after'])
        else:
            cheapest = most_expensive = None
        
        return {
            'medicine_name': medicine_name,
            'total_variants': len(matches),
            'available_variants': len(available),
            'sold_out_variants': len(sold_out),
            'cheapest_available': cheapest,
            'most_expensive_available': most_expensive,
            'all_available': available[:10],  # Limit to 10 for display
            'companies': list(set(m['company'] for m in matches))
        }
    
    def get_companies(self) -> List[str]:
        """Get list of all pharmaceutical companies"""
        companies = list(set(m['company'] for m in self.medicines))
        return sorted(companies)
    
    def get_medicine_stats(self) -> Dict:
        """Get statistics about medicines"""
        total_medicines = len(self.medicines)
        available_count = len(self.get_available_medicines())
        companies = len(self.get_companies())
        
        prices = [m['price_after'] for m in self.medicines if m['price_after'] > 0]
        avg_price = sum(prices) / len(prices) if prices else 0
        
        return {
            'total_medicines': total_medicines,
            'available_medicines': available_count,
            'sold_out_medicines': total_medicines - available_count,
            'total_companies': companies,
            'average_price': round(avg_price, 2),
            'price_range': {
                'min': min(prices) if prices else 0,
                'max': max(prices) if prices else 0
            }
        }

