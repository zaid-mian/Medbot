import pandas as pd
import json
from typing import List, Dict, Optional
import math

class HospitalDataProcessor:
    def __init__(self, csv_path: str):
        """Initialize with hospital CSV data"""
        self.df = pd.read_csv(csv_path)
        self.hospitals = self._process_data()
    
    def _process_data(self) -> List[Dict]:
        """Process and clean hospital data"""
        hospitals = []
        for _, row in self.df.iterrows():
            hospital = {
                'name': str(row['HOSPITAL NAME']).strip(),
                'city': str(row['CITY']).strip(),
                'area': str(row['AREA']).strip() if pd.notna(row['AREA']) else '',
                'address': str(row['ADDRESS']).strip(),
                'doctors': self._parse_doctors(row['DOCTORS']),
                'contact': str(row['CONTACT']).strip()
            }
            hospitals.append(hospital)
        return hospitals
    
    def _parse_doctors(self, doctors_value) -> int:
        """Parse doctor count from various formats"""
        if pd.isna(doctors_value) or doctors_value == '-' or doctors_value == 'nill':
            return 0
        try:
            return int(doctors_value)
        except (ValueError, TypeError):
            return 0
    
    def search_by_city(self, city: str) -> List[Dict]:
        """Search hospitals by city"""
        city_lower = city.lower()
        return [h for h in self.hospitals if city_lower in h['city'].lower()]
    
    def search_by_area(self, area: str, city: str = None) -> List[Dict]:
        """Search hospitals by area and optionally city"""
        area_lower = area.lower()
        results = [h for h in self.hospitals if area_lower in h['area'].lower()]
        
        if city:
            city_lower = city.lower()
            results = [h for h in results if city_lower in h['city'].lower()]
        
        return results
    
    def search_by_specialty(self, specialty: str) -> List[Dict]:
        """Search hospitals by specialty keywords in name"""
        specialty_lower = specialty.lower()
        specialty_keywords = {
            'eye': ['eye', 'vision', 'ophthal'],
            'heart': ['heart', 'cardio', 'cardiac'],
            'dental': ['dental', 'teeth', 'oral'],
            'children': ['child', 'pediatric', 'kids'],
            'brain': ['brain', 'neuro', 'spine'],
            'skin': ['skin', 'dermat', 'laser'],
            'emergency': ['emergency', 'trauma'],
            'general': ['general', 'medical', 'clinic']
        }
        
        keywords = specialty_keywords.get(specialty_lower, [specialty_lower])
        results = []
        
        for hospital in self.hospitals:
            name_lower = hospital['name'].lower()
            if any(keyword in name_lower for keyword in keywords):
                results.append(hospital)
        
        return results
    
    def get_nearby_hospitals(self, city: str, limit: int = 10) -> List[Dict]:
        """Get hospitals in a city with preference for those with more doctors"""
        hospitals = self.search_by_city(city)
        # Sort by number of doctors (descending) and then by name
        hospitals.sort(key=lambda x: (-x['doctors'], x['name']))
        return hospitals[:limit]
    
    def get_all_cities(self) -> List[str]:
        """Get list of all unique cities"""
        cities = list(set(h['city'] for h in self.hospitals))
        return sorted(cities)
    
    def get_hospital_stats(self) -> Dict:
        """Get statistics about hospitals"""
        total_hospitals = len(self.hospitals)
        total_doctors = sum(h['doctors'] for h in self.hospitals)
        cities = len(self.get_all_cities())
        
        return {
            'total_hospitals': total_hospitals,
            'total_doctors': total_doctors,
            'cities_covered': cities,
            'avg_doctors_per_hospital': round(total_doctors / total_hospitals, 2) if total_hospitals > 0 else 0
        }

