import time
import os
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from src.data.hospitals import HospitalDataProcessor
from src.data.medicines import MedicineDataProcessor

medical_bp = Blueprint('medical', __name__)

# Initialize data processors
current_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(current_dir, '..', 'data')

hospitals_csv = os.path.join(data_dir, 'pakistan_hospitals_details.csv')
medicines_excel = os.path.join(data_dir, 'Pakistan_Pharmaceutical_Products_Pricing_and_Availability_Data.xlsx')

hospital_processor = HospitalDataProcessor(hospitals_csv)
medicine_processor = MedicineDataProcessor(medicines_excel)

@medical_bp.route('/hospitals/search', methods=['POST'])
@cross_origin()
def search_hospitals():
    """Search hospitals by various criteria"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Request data is required'}), 400
        
        search_type = data.get('type', 'city')  # city, area, specialty
        query = data.get('query', '').strip()
        city = data.get('city', '').strip()
        limit = data.get('limit', 10)
        
        if not query:
            return jsonify({'error': 'Search query is required'}), 400
        
        if search_type == 'city':
            results = hospital_processor.search_by_city(query)
        elif search_type == 'area':
            results = hospital_processor.search_by_area(query, city if city else None)
        elif search_type == 'specialty':
            results = hospital_processor.search_by_specialty(query)
        elif search_type == 'nearby':
            results = hospital_processor.get_nearby_hospitals(query, limit)
        else:
            return jsonify({'error': 'Invalid search type'}), 400
        
        return jsonify({
            'success': True,
            'results': results[:limit],
            'total_found': len(results),
            'search_type': search_type,
            'query': query
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Search failed: {str(e)}'
        }), 500

@medical_bp.route('/hospitals/cities', methods=['GET'])
@cross_origin()
def get_cities():
    """Get list of all cities with hospitals"""
    try:
        cities = hospital_processor.get_all_cities()
        stats = hospital_processor.get_hospital_stats()
        
        return jsonify({
            'success': True,
            'cities': cities,
            'stats': stats
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Failed to get cities: {str(e)}'
        }), 500

@medical_bp.route('/medicines/search', methods=['POST'])
@cross_origin()
def search_medicines():
    """Search medicines by name"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Request data is required'}), 400
        
        medicine_name = data.get('name', '').strip()
        search_type = data.get('type', 'name')  # name, company, alternatives
        limit = data.get('limit', 10)
        
        if not medicine_name:
            return jsonify({'error': 'Medicine name is required'}), 400
        
        if search_type == 'name':
            results = medicine_processor.search_by_name(medicine_name)
        elif search_type == 'company':
            results = medicine_processor.search_by_company(medicine_name)
        elif search_type == 'alternatives':
            results = medicine_processor.get_medicine_alternatives(medicine_name)
        elif search_type == 'cheapest':
            results = medicine_processor.get_cheapest_medicines(medicine_name, limit)
        else:
            return jsonify({'error': 'Invalid search type'}), 400
        
        # Filter to available medicines only
        available_results = [m for m in results if m['availability'].lower() == 'available']
        
        return jsonify({
            'success': True,
            'results': available_results[:limit],
            'total_found': len(available_results),
            'search_type': search_type,
            'medicine_name': medicine_name
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Medicine search failed: {str(e)}'
        }), 500

@medical_bp.route('/medicines/info/<medicine_name>', methods=['GET'])
@cross_origin()
def get_medicine_info(medicine_name):
    """Get detailed information about a specific medicine"""
    try:
        info = medicine_processor.get_medicine_info(medicine_name)
        
        if not info:
            return jsonify({
                'success': False,
                'error': 'Medicine not found'
            }), 404
        
        return jsonify({
            'success': True,
            'medicine_info': info
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Failed to get medicine info: {str(e)}'
        }), 500

@medical_bp.route('/medicines/companies', methods=['GET'])
@cross_origin()
def get_companies():
    """Get list of all pharmaceutical companies"""
    try:
        companies = medicine_processor.get_companies()
        stats = medicine_processor.get_medicine_stats()
        
        return jsonify({
            'success': True,
            'companies': companies,
            'stats': stats
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Failed to get companies: {str(e)}'
        }), 500

@medical_bp.route('/health', methods=['GET'])
@cross_origin()
def medical_health():
    """Health check for medical services"""
    try:
        hospital_stats = hospital_processor.get_hospital_stats()
        medicine_stats = medicine_processor.get_medicine_stats()
        
        return jsonify({
            'status': 'healthy',
            'service': 'Medical Data API',
            'timestamp': time.time(),
            'data_status': {
                'hospitals': hospital_stats,
                'medicines': medicine_stats
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

