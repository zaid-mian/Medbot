import time
import os
import base64
import google.generativeai as genai
from google.api_core.exceptions import ResourceExhausted
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from PIL import Image
import io
from src.data.hospitals import HospitalDataProcessor
from src.data.medicines import MedicineDataProcessor

chat_bp = Blueprint("chat", __name__)

# Configure Gemini API
API_KEY = "AIzaSyC_Y-TVO3PpYCipcRYnU0fdBcGMMYm0ik8"
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemini-1.5-flash")

# Initialize data processors
current_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(current_dir, "..", "data")

hospitals_csv = os.path.join(data_dir, "pakistan_hospitals_details.csv")
medicines_excel = os.path.join(data_dir, "Pakistan_Pharmaceutical_Products_Pricing_and_Availability_Data.xlsx")

hospital_processor = HospitalDataProcessor(hospitals_csv)
medicine_processor = MedicineDataProcessor(medicines_excel)

# Medical assistant system prompt
MEDICAL_SYSTEM_PROMPT = """You are a Medical Assistant AI specifically designed for Pakistan. Your role is to:

1. **Primary Function**: Provide preliminary medical advice and symptom analysis for Pakistani patients
2. **Medical Knowledge**: Focus on common conditions in Pakistan, local medical practices, and culturally appropriate advice
3. **Language**: Communicate in clear, empathetic English suitable for Pakistani patients
4. **Limitations**: Always remind users that this is preliminary advice and they should consult qualified healthcare professionals

**IMPORTANT GUIDELINES:**
- Respond naturally to greetings like "hi", "hello", "assalam alaikum" with a warm welcome
- For medical symptoms, ask follow-up questions to better understand the condition
- Provide structured advice with clear sections for medical queries
- Include emergency warnings when appropriate
- Always suggest specific local medicines available in Pakistan with brand names
- Recommend seeking professional medical help for serious symptoms
- Be culturally sensitive to Pakistani healthcare practices

**GREETING RESPONSES:**
When users greet you with "hi", "hello", "assalam alaikum", or similar:
- Respond warmly and introduce yourself as a medical assistant
- Ask them to describe their symptoms or health concerns
- Keep it brief and welcoming

**MEDICAL RESPONSE FORMAT (for symptom queries):**
1. **Acknowledgment**: Show understanding of the patient's concern
2. **Follow-up Questions**: Ask relevant questions to assess the condition (4-5 specific questions)
3. **Preliminary Assessment**: Provide possible causes based on symptoms
4. **Recommended Medications**: Always include specific Pakistani medicine brands with:
   - Generic and brand names (Panadol, Brufen, etc.)
   - Typical dosages for adults
   - Over-the-counter availability
   - Warnings and contraindications
5. **When to See a Doctor**: Clear guidance on when professional help is needed
6. **Emergency Contacts**: Include Pakistan emergency numbers (1122)

**MEDICINE INFORMATION (ALWAYS INCLUDE):**
For any medical condition, suggest relevant medicines:
- Paracetamol: Panadol, Calpol, Disprin, Feverex
- Ibuprofen: Brufen, Nurofen, Advil
- Antihistamines: Cetrizine, Zyrtec, Histazine
- Include prices, availability, and local pharmacy information

**HOSPITAL RECOMMENDATIONS:**
When users ask about hospitals or if location is provided, suggest:
- Nearby hospitals based on their location
- Specialist hospitals for specific conditions
- Emergency services information

Remember: You are providing preliminary guidance only. Always emphasize the importance of professional medical consultation for proper diagnosis and treatment."""

def get_location_context(location_data):
    """Get location context for hospital recommendations"""
    if not location_data:
        return ""
    
    lat = location_data.get("latitude", 0)
    lng = location_data.get("longitude", 0)
    
    if 31.5 <= lat <= 31.6 and 74.3 <= lng <= 74.4:
        city = "Lahore"
    elif 24.8 <= lat <= 24.9 and 67.0 <= lng <= 67.1:
        city = "Karachi"
    elif 33.6 <= lat <= 33.7 and 73.0 <= lng <= 73.1:
        city = "Islamabad"
    elif 30.1 <= lat <= 30.2 and 71.4 <= lng <= 71.5:
        city = "Multan"
    else:
        city = "Pakistan"  # Default
    
    return f"\n\nUser's location: {city}, Pakistan. When recommending hospitals, prioritize facilities in or near {city}."

def get_medicine_context(user_message):
    """Get medicine information context if user asks about medicines"""
    medicine_keywords = ['medicine', 'drug', 'tablet', 'panadol', 'brufen', 'price', 'pharmacy', 'medication', 'syrup', 'injection', 'cream']
    
    if any(keyword in user_message.lower() for keyword in medicine_keywords):
        words = user_message.lower().split()
        potential_medicines = []
        for word in words:
            if len(word) > 2: # Consider words longer than 2 characters
                potential_medicines.extend(medicine_processor.search_by_name(word))
        
        if potential_medicines:
            # Remove duplicates and limit to top 5 relevant ones
            unique_medicines = []
            seen_names = set()
            for med in potential_medicines:
                if med['name'] not in seen_names:
                    unique_medicines.append(med)
                    seen_names.add(med['name'])
            
            context = "\n\nRelevant medicine information from Pakistan database:\n"
            for med in unique_medicines[:5]: # Limit to 5 for brevity in prompt
                context += f"- Name: {med['name']}, Company: {med['company']}, Price: Rs {med['price_after']}, Pack Size: {med['pack_size']}, Availability: {med['availability']}\n"
            return context
    
    return ""

def get_hospital_context(user_message, location_data):
    """Get hospital information context if user asks about hospitals"""
    hospital_keywords = ['hospital', 'clinic', 'doctor', 'emergency', 'near me', 'nearby', 'specialist']
    
    if any(keyword in user_message.lower() for keyword in hospital_keywords):
        city = None
        if location_data:
            lat = location_data.get("latitude", 0)
            lng = location_data.get("longitude", 0)
            
            if 31.5 <= lat <= 31.6 and 74.3 <= lng <= 74.4:
                city = "Lahore"
            elif 24.8 <= lat <= 24.9 and 67.0 <= lng <= 67.1:
                city = "Karachi"
            elif 33.6 <= lat <= 33.7 and 73.0 <= lng <= 73.1:
                city = "Islamabad"
            elif 30.1 <= lat <= 30.2 and 71.4 <= lng <= 71.5:
                city = "Multan"
            # Add more cities as needed or use a more robust geocoding service

        hospitals = []
        if city:
            hospitals = hospital_processor.get_nearby_hospitals(city, limit=5) # Get top 5 hospitals in the city
        
        if hospitals:
            context = f"\n\nRelevant hospital information for {city if city else 'your area'} from Pakistan database:\n"
            for hosp in hospitals:
                context += f"- Name: {hosp['name']}, City: {hosp['city']}, Area: {hosp['area']}, Address: {hosp['address']}, Contact: {hosp['contact']}, Doctors: {hosp['doctors']}\n"
            return context
        elif city:
            return f"\n\nNo specific hospital information found for {city}. Please try a different city or a more general query."
        else:
            return "\n\nFor hospital recommendations, please enable location sharing or specify your city in the message (e.g., 'hospitals in Lahore')."
    
    return ""

def process_image(image_data):
    """Process base64 image data and return PIL Image object"""
    try:
        if ',' in image_data:
            image_data = image_data.split(',')[1]
        
        image_bytes = base64.b64decode(image_data)
        image = Image.open(io.BytesIO(image_bytes))
        
        if image.mode != 'RGB':
            image = image.convert('RGB')
            
        return image
    except Exception as e:
        raise ValueError(f"Invalid image data: {str(e)}")

@chat_bp.route('/chat', methods=['POST'])
@cross_origin()
def chat():
    try:
        if request.is_json:
            data = request.get_json()
            message = data.get('message', '').strip()
            image_data = data.get('image', None)
            location_data = data.get('location')
            context = data.get('context', '')
        else:
            message = request.form.get('message', '').strip()
            image_data = request.form.get('image', None)
            location_data = None
            context = ''
            
            if 'image_file' in request.files:
                file = request.files['image_file']
                if file and file.filename:
                    image_bytes = file.read()
                    image_data = base64.b64encode(image_bytes).decode('utf-8')
        
        if not message and not image_data:
            return jsonify({
                'success': False,
                'error': 'Message or image is required'
            }), 400
        
        enhanced_prompt = MEDICAL_SYSTEM_PROMPT
        
        if location_data:
            enhanced_prompt += get_location_context(location_data)
        
        if message:
            enhanced_prompt += get_medicine_context(message)
            enhanced_prompt += get_hospital_context(message, location_data)
            enhanced_prompt += f"\n\nPatient's message: {message}"
        
        content_parts = [enhanced_prompt]
        
        if image_data:
            try:
                image = process_image(image_data)
                content_parts.append(image)
                enhanced_prompt += "\n\nPlease analyze the provided medical image and provide relevant medical advice."
            except ValueError as e:
                return jsonify({
                    'success': False,
                    'error': str(e)
                }), 400
        
        max_retries = 2
        for attempt in range(max_retries):
            try:
                if len(content_parts) == 1:
                    response = model.generate_content(content_parts[0])
                else:
                    response = model.generate_content(content_parts)
                
                return jsonify({
                    'success': True,
                    'response': response.text,
                    'timestamp': time.time(),
                    'context': 'medical_assistant_pakistan',
                    'has_image': bool(image_data)
                })
                
            except ResourceExhausted as e:
                if attempt < max_retries - 1:
                    time.sleep(20)  # Wait before retry
                    continue
                else:
                    return jsonify({
                        'success': False,
                        'error': 'API quota exceeded. Please try again later.',
                        'retry_after': 60
                    }), 429
            
            except Exception as e:
                if attempt < max_retries - 1:
                    time.sleep(5)  # Brief wait before retry
                    continue
                else:
                    return jsonify({
                        'success': False,
                        'error': f'AI response generation failed: {str(e)}'
                    }), 500
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Request processing failed: {str(e)}'
        }), 500

@chat_bp.route('/chat/health', methods=['GET'])
@cross_origin()
def chat_health():
    """Health check for chat service"""
    try:
        test_response = model.generate_content("Hello")
        
        return jsonify({
            'status': 'healthy',
            'service': 'Medical Chat API',
            'timestamp': time.time(),
            'gemini_api': 'connected',
            'data_processors': {
                'hospitals': len(hospital_processor.hospitals),
                'medicines': len(medicine_processor.medicines)
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500



